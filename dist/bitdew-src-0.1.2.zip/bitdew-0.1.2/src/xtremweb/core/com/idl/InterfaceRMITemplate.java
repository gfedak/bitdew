package xtremweb.core.com.idl;

/**
 * Describe class InterfaceRMITemplate here.
 *
 *
 * Created: Sun Sep 24 11:00:19 2006
 *
 * @author <a href="mailto:fedak@xtremciel.gillus.net">Gilles Fedak</a>
 * @version 1.0
 */
import java.rmi.*;
import xtremweb.core.poxwo.*;

public interface InterfaceRMITemplate extends Remote{




}
