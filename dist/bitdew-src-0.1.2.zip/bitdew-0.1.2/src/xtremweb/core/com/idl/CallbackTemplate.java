package xtremweb.core.com.idl;

/**
 * CallbackTemplate.java
 * Handles RMI communications from servers  
 * 
 * Created: on a rainning sunday
 *
 * @author Gilles Fedak
 * @version
 */

import xtremweb.core.poxwo.*;

public class CallbackTemplate {

    public CallbackTemplate() {}

}
