package xtremweb.core.perf;

/**
 * @author <a href="mailto:fedak@lri.fr">Gilles Fedak</a>
 * @version 1.0
 */
public class PerfException extends Exception {

    public PerfException(String message) {
	super(message);
    }
}