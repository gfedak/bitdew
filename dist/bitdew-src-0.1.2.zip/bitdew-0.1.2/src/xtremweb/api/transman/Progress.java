package xtremweb.api.transman;

/**
 * Describe class Progress here.
 *
 *
 * Created: Fri Mar 28 22:40:52 2008
 *
 * @author <a href="mailto:fedak@xtremciel.local">Gilles Fedak</a>
 * @version 1.0
 */
public class Progress {

    private int status;
    private int bytes;
    /**
     * Creates a new <code>Progress</code> instance.
     *
     */
    public Progress() {

    }

}
