package xtremweb.serv.dc.ddc;

/**
 * Describe class DistributedDataCatalogImpl here.
 *
 *
 * Created: Thu Aug 31 13:59:43 2006
 *
 * @author <a href="mailto:fedak@xtremciel.local">Gilles Fedak</a>
 * @version 1.0
 */
import xtremweb.core.log.*;
import xtremweb.serv.dc.*;

public abstract class DistributedDataCatalogImpl implements DistributedDataCatalog {
      protected Logger logger = LoggerFactory.getLogger("DDC Factory");
}
