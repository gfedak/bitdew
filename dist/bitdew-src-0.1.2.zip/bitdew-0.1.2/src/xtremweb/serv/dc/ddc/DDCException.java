package xtremweb.serv.dc.ddc;

/**
 * Describe class DDCException here.
 *
 *
 * Created: Thu Aug 31 16:05:22 2006
 *
 * @author <a href="mailto:fedak@xtremciel.local">Gilles Fedak</a>
 * @version 1.0
 */
public class DDCException extends Exception {

    /**
     * Creates a new <code>DDCException</code> instance.
     *
     */
    public DDCException() {

    }

}
