package xtremweb.serv.dt.bittorrent;

import xtremweb.core.exec.*;


/**
 * Describe class PythonBittorrentConnector here.
 *
 *
 * Created: Wed Mar 28 11:30:00 2007
 *
 * @author <a href="mailto:fedak@xtremciel.gillus.net">Gilles Fedak</a>
 * @version 1.0
 */
public class PythonBittorrentConnector {

    /**
     * Creates a new <code>PythonBittorrentConnector</code> instance.
     *
     */
    public PythonBittorrentConnector() {

    }

}
